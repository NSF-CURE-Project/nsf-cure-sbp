const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "kN",
            "distload": "kN/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;

  

length = math.randomInt(8,10);
distload = math.randomInt(5,7);

R_a = (distload*length)/6;
R_b = (distload*length)/3;


location1 = math.round( length/(3)**0.5, 2);
M_max = math.round( (distload*length*location1)/6 - (((location1)**3)*distload)/(6*length), 1);
location2 = math.round( length/(3)**0.5,2);
M_x3 = math.round( (distload*length*3)/6 - ((3**3)*distload)/(6*length), 1);


data = {
    params: {
    
    

    length:length,
    distload:distload,


    unitsDist:unitsDist,
    unitsMoment:unitsMoment,
    unitsDistload:unitsDistload,
    unitsForce:unitsForce,




    },
    correct_answers: {
        
    
    M_max:M_max,
    location1:location1,
    location2:location2,
    M_x3:M_x3,
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}