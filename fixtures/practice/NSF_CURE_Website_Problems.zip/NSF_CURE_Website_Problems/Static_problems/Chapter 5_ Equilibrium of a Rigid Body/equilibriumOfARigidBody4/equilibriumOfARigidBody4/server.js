const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;



dist1 = math.randomInt(250,300);
dist2 = math.randomInt(400,450);
force1 = math.randomInt(40,50);
force2 = math.randomInt(20,30);

A_x = force1*(5/13) - force2*math.cos(math.pi/3);
A_y = force1*(12/13) + force2*math.sin(math.pi/3);


M_A = math.round( force1*(12/13)*(dist1/1000) + force2*math.sin(math.pi/3)*(dist2/1000), 1);
F_A = math.round( math.sqrt(A_x**2 + A_y**2), 1);


data = {
    params: {
    
    
    force1:force1,
    force2:force2,
    dist1:dist1,
    dist2:dist2,

    
    unitsForce:unitsForce,
    unitsLength:unitsLength,
    unitsMoment:unitsMoment,


    },
    correct_answers: {
        
    M_A:M_A,
    F_A:F_A,


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}