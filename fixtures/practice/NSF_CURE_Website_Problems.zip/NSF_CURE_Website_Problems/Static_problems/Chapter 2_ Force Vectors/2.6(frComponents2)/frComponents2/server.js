const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;



force1 = math.randomInt(800,900);
force2 = math.randomInt(600,650);
force3 = math.randomInt(700,775);                                

F_x = force1*(4/5) - force2*math.sin(math.pi/6) - force3*math.sin(math.pi/4);
F_y = -force1*(3/5) - force2*math.cos(math.pi/6) + force3*math.cos(math.pi/4);

F_R = math.round( math.sqrt(F_x**2 + F_y**2) );
phi = math.atan(F_y/F_x)*(180/math.pi); 
theta = math.round( 180 + phi );

data = {
    params: {
    
    
    force1:force1,
    force2:force2,
    force3:force3,


    
    unitsForce:unitsForce,
    unitsAngle:unitsAngle,



    },
    correct_answers: {
        
    F_R:F_R,
    theta:theta,
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}