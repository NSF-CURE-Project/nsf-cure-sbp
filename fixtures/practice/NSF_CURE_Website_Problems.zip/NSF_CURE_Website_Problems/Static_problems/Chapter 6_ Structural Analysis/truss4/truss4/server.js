const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "kN",
            "distload": "N/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;



force1 = math.randomInt(2,3);
force2 = math.randomInt(5,6);

F_gc = 0;
F_df = 0;
F_fc = 0;


data = {
    params: {
    
    
    force1:force1,
    force2:force2,


    
    unitsForce:unitsForce,



    },
    correct_answers: {
        
    F_gc:F_gc,
    F_df:F_df,
    F_fc:F_fc,


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}