const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "kN",
            "distload": "N/m",
            "moment": "N-m",
            "inertia": "mm\u2074",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "inertia": "in^4",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsInertia = units[unitSystems[unitSel]].inertia;



I_x1 = 1425000000;
I_x2 = 50000000;
I_x3 = 1425000000;
I_y1 = 1900000000;
I_y2 = 1800000000;
I_y3 = 1900000000;
I_x = 2900000000;
I_y = 5600000000;



data = {
    params: {
    
    
    
    unitsInertia:unitsInertia,



    },
    correct_answers: {
        
    I_x1:I_x1,
    I_x2:I_x2,
    I_x3:I_x3,
    I_y1:I_y1,
    I_y2:I_y2,
    I_y3:I_y3,
    I_x:I_x,
    I_y:I_y,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}