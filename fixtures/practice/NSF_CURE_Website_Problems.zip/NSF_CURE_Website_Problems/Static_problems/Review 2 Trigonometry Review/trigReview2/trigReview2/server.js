const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "diameter":"mm",
            "degrees":"°",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "modulus":"GPa",
            "distload": "kN/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "ft",
            "diameter":"in",
            "degrees":"°",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "lb",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "modulus":"psi",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsModulus = units[unitSystems[unitSel]].modulus;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    unitsDegrees = units[unitSystems[unitSel]].degrees;

  

force1 = math.pickRandom([10,15,20]);
force2 = math.pickRandom([28,24,26]);
force3 = math.pickRandom([34,36,38]);


f1x = math.round( force1*math.sin(math.pi/4), 1);
f1y = math.round( force1*math.cos(math.pi/4), 1);
f2x = math.round( -force2*(12/13), 1);
f2y = math.round( force2*(5/13), 1);
f3x = math.round( force3*math.cos(math.pi/6), 1);
f3y = math.round( -force3*math.sin(math.pi/6), 1);

data = {
    params: {
    


    force1:force1,
    force2:force2,
    force3:force3,
    


   
    unitsForce:unitsForce,


    


    },
    correct_answers: {
    
    f1x:f1x,
    f1y:f1y,
    f2x:f2x,
    f2y:f2y,
    f3x:f3x,
    f3y:f3y,


    
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}