const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "kN",
            "stress":"kPa",
            "shearstrain":"rad",
            "distload": "N/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "kip",
            "stress":"ksi",
            "shearstrain":"rad",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;

  
diameter = math.pickRandom([1.20,1.25,1.30]);
force1 = 75;
force2 = math.pickRandom([140,150,160]);

v = force1/2;
A = (math.pi/4)*(diameter)**2;
towel = v/A;

elastic = math.round( (towel*0.005)/50, 4);

v2 = force2/2;
towel2 = v2/A;
ss = ((0.045*towel2) - 2.125)/25;
G = 50/0.005;
ssr = towel2/G;

plastic = math.round( ss - ssr, 4);


data = {
    params: {
    
    diameter:diameter,
    force1:force1,
    force2:force2,



    unitsLength:unitsLength,
    unitsForce:unitsForce,
    unitsShearstrain:unitsShearstrain,
    




    },
    correct_answers: {
        
    elastic:elastic,
    plastic:plastic,
    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}