const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "force": "kN",
            "stress":"kPa",
            "distload": "N/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "force": "lb",
            "stress":"psi",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsStress = units[unitSystems[unitSel]].stress;

  
e = math.pickRandom([0.006,0.007,0.008]);
sig = math.pickRandom([460,470,480,490,500]);
diameter1 = math.pickRandom([12.7,12.8,12.9]);
diameter2 = math.pickRandom([12.67494,12.77494,12.87494]);
force = math.pickRandom([40,50,60]);
length = math.pickRandom([50.7,50.8,50.9]);

area = (math.pi/4)*(diameter1/1000)**2;
sigma = (force*1000)/area;
E = (sig*1000000)/e;
e_long = sigma/E;
e_lat = (diameter2-diameter1)/diameter1;

v = math.round( e_lat/e_long, 6);

data = {
    params: {
    
    e:e,
    sig:sig,
    length:length,
    diameter1:diameter1,
    diameter2:diameter2,
    force:force,


    unitsLength:unitsLength,
    unitsForce:unitsForce,
    




    },
    correct_answers: {
        
    v:v,
    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}