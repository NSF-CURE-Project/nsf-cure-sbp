const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "kN",
            "distload": "N/m",
            "moment": "N-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "weight": "lb/ft",
            "dist": "ft",
            "diameter": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "kip-ft",
            "torque": "lb-in",
            "stress": "ksi",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsWeight = units[unitSystems[unitSel]].weight;
 

moment = math.pickRandom([500,600,700,800]);


I = 34.53125;
ts = (moment*0.05625)/I;
cs = (moment*0.03125)/I;
Fr = math.round( 0.5*0.025*0.24*(ts+cs)*1000, 2);


data = {
    params: {

    moment:moment,
   


    unitsForce:unitsForce,
    unitsMoment:unitsMoment,



    },
    correct_answers: {
        Fr:Fr,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}