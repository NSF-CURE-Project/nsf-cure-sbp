const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2",
            "shear": "kN",
            "width": "mm",
            "ybar": "m",
            "inertia": "m\u2074"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "inches",
            "force": "lb",
            "distload": "kip/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "psi",
            "shear": "kip"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShear = units[unitSystems[unitSel]].shear;
    unitsWidth = units[unitSystems[unitSel]].width;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsYbar = units[unitSystems[unitSel]].ybar;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    
 



shear = math.pickRandom([4,5,6,7]);
F = 500;
ybar = 6.375;
I = 1196.4375;
Qt = 5.625*10*1.5;
Qb = 7.875*6*1.5;
qt = (shear*1000*Qt)/I;
qb = (shear*1000*Qb)/I;
st = math.round( F/qt, 2);
sb = math.round( F/qb, 2);


data = {
    params: {

    
    shear:shear,
    

   

    unitsDist: unitsDist, 
    unitsShear: unitsShear,





    },
    correct_answers: {
        st:st,
        sb:sb,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}