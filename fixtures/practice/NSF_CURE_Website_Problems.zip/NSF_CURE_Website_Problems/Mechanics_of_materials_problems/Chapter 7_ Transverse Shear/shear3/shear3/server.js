const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2",
            "shear": "kN",
            "width": "mm",
            "ybar": "m",
            "inertia": "m\u2074"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShear = units[unitSystems[unitSel]].shear;
    unitsWidth = units[unitSystems[unitSel]].width;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsYbar = units[unitSystems[unitSel]].ybar;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    
 

shear = math.pickRandom([40,50,60,70]);
bst = 15*0.175/200;
I = 0.113648*10**-3; 
Q = (0.075*bst*0.15) + (0.155*0.175*0.01);
t1 = math.round ( (15/200)*shear*1000*Q/(I*bst*10**6), 2);



data = {
    params: {

    
    shear:shear,
    

   

    unitsShear: unitsShear, 
    unitsStress: unitsStress,





    },
    correct_answers: {
        t1:t1,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}