const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2",
            "shear": "kN",
            "width": "mm",
            "ybar": "m",
            "inertia": "m\u2074"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShear = units[unitSystems[unitSel]].shear;
    unitsWidth = units[unitSystems[unitSel]].width;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsYbar = units[unitSystems[unitSel]].ybar;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    
 

shear = math.pickRandom([20,30,40,50]);
width = 200;
ybar = 0.2433; 
inertia = 0.5382*10**-3;


Qa = 0.1867*0.3*0.02;
Qb = 0.2333*0.2*0.02;
ta = math.round ( ((shear*1000*Qa)/(inertia*0.02))/(10**6), 2);
tb = math.round ( ((shear*1000*Qb)/(inertia*0.02))/(10**6), 2);



data = {
    params: {

    
    shear:shear,
    width: width,
    ybar: ybar,
    inertia: inertia,

   

    unitsShear: unitsShear, 
    unitsWidth: unitsWidth, 
    unitsYbar: unitsYbar,
    unitsInertia: unitsInertia,
    unitsStress: unitsStress,





    },
    correct_answers: {
        ta:ta,
        tb:tb,


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}