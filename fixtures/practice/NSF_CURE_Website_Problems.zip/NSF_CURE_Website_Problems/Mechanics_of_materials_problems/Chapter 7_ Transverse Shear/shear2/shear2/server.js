const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2",
            "shear": "kN",
            "width": "mm",
            "ybar": "m",
            "inertia": "m\u2074"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "force": "lb",
            "distload": "kip/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "psi"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShear = units[unitSystems[unitSel]].shear;
    unitsWidth = units[unitSystems[unitSel]].width;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsYbar = units[unitSystems[unitSel]].ybar;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    
 



stress = math.pickRandom([700,750,800,850,900]);
ybar = 3.5;
I = (1/12)*2*(4**3) + 2*4*(3.5-2)**2 + (1/12)*4*(2**3) + 4*2*(5-3.5)**2;
Q = 1.75*2*3.5;
w = math.round ( (stress*I*2)/(3*Q*1000), 2);

data = {
    params: {

    
    stress:stress,
    

   

    unitsDistload: unitsDistload, 
    unitsStress: unitsStress,





    },
    correct_answers: {
        w:w,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}