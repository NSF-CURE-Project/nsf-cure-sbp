const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "diameter":"mm",
            "degrees":"°",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "modulus":"GPa",
            "distload": "kN/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "ft",
            "diameter":"in",
            "degrees":"°",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "lb",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "modulus":"psi",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsModulus = units[unitSystems[unitSel]].modulus;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    unitsDegrees = units[unitSystems[unitSel]].degrees;

  


sigma1 = math.pickRandom([35,40,45]); 
sigma2 = math.pickRandom([-55,-60,-65]); 
tau1 = math.pickRandom([25,30,35]); 


center = (sigma1 + sigma2) / 2;
R = math.sqrt(((sigma1 - sigma2) / 2) ** 2 + tau1 ** 2);

// tan(2θp) = τxy / ((σx - σy)/2)
value = tau1 / ((sigma1 - sigma2) / 2);

// tan(2θs) = -((σx - σy)/2) / τxy
value2 = -((sigma1 - sigma2) / 2) / tau1;

s1 = math.round(center + R, 1);
s2 = math.round(center - R, 1);

// atan gives 2θ, so divide by 2
theta1 = math.round(math.atan(value) * 180 / math.pi / 2, 1);
theta2 = math.round(theta1 - 90, 1);

tmax = math.round(R, 1);
savg = math.round(center, 2);   // <-- this is MPa, fix the HTML label

thetas1 = math.round(math.atan(value2) * 180 / math.pi / 2, 1);
thetas2 = math.round(thetas1 + 90, 1);

data = {
    params: {
    


    sigma1:sigma1,
    sigma2:sigma2,
    tau1:tau1,


    


    unitsStress:unitsStress,
    unitsDegrees:unitsDegrees,


    


    },
    correct_answers: {
    
    s1:s1,
    s2:s2,
    theta1:theta1,
    theta2:theta2,
    tmax:tmax,
    savg:savg,
    thetas1:thetas1,
    thetas2:thetas2,
    

    
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}