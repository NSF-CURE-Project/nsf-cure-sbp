const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "diameter":"mm",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "modulus":"GPa",
            "distload": "kN/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "ft",
            "diameter":"in",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "lb",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "modulus":"psi",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsModulus = units[unitSystems[unitSel]].modulus;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    

  


sigma1 = math.pickRandom([50,60,65,70]);
tau1 = math.pickRandom([10,15,20,25]);

s = math.round( -tau1*(math.sin(math.pi/6)*math.cos(math.pi/6)) - tau1*(math.cos(math.pi/6)*math.cos(math.pi/3)) + sigma1*(math.cos(math.pi/6)*math.cos(math.pi/6)), 1);
t = math.round( -tau1*(math.sin(math.pi/6)*math.sin(math.pi/6)) + tau1*(math.cos(math.pi/6)*math.sin(math.pi/3)) + sigma1*(math.cos(math.pi/6)*math.sin(math.pi/6)), 1);


data = {
    params: {
    


    sigma1:sigma1,
    tau1:tau1,

    


    unitsStress:unitsStress,


    


    },
    correct_answers: {
        
    s:s,
    t:t,
    
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}