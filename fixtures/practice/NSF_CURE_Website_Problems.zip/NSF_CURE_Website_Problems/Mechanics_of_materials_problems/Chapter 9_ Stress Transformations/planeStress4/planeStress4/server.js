const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "diameter":"mm",
            "degrees":"°",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "modulus":"GPa",
            "distload": "kN/m",
            "moment": "kN-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "ft",
            "diameter":"in",
            "degrees":"°",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "lb",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "modulus":"psi",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsModulus = units[unitSystems[unitSel]].modulus;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    unitsDegrees = units[unitSystems[unitSel]].degrees;

  

force1 = math.pickRandom([10,12,14,16]);

Ay = (force1 * 4) / 7;  // kN

// Internal forces at point A (x = 2m from left support)
M = 2 * Ay * 1000;   // N·m
V = Ay * 1000;        // N

// Fixed cross-section geometry (200mm × 300mm)
b   = 0.2;        // m
h   = 0.3;        // m
y_A = 0.075;      // m (distance from NA to point A)

I_val = (1/12) * b * h**3;               // 4.5e-4 m⁴
Q_val = (h/2 - y_A/2) * b * y_A;         // 1.6875e-3 m³ (ȳ'·A')
t_val = b;                                // 0.2 m (width at A)

// Stress components at A (in Pa)
sx  = (M * y_A) / I_val;                 // bending stress
sy  = 0;
txy = -(V * Q_val) / (I_val * t_val);    // shear stress

// Reusable intermediates (Mohr's circle center and radius)
center = (sx + sy) / 2;
R = math.sqrt(((sx - sy) / 2)**2 + txy**2);

// Principal stresses in MPa — sigma2 is tiny so use more decimal places
sigma1 = math.round(1e-6 * (center + R), 4);   // ≈ 2.2929 → 2.29 MPa
sigma2 = math.round(1e-6 * (center - R), 6);   // ≈ -0.007205 → -0.00720 MPa

// Orientation: tan(2θp) = τxy/((σx−σy)/2), θp = atan(value)/2
value = txy / ((sx - sy) / 2);
thetap = math.round(math.atan(value) * 180 / math.pi / 2, 2);  // ≈ -3.21°

data = {
    params: {
    


    force1:force1,

    


    unitsStress:unitsStress,
    unitsDegrees:unitsDegrees,
    unitsForce:unitsForce,


    


    },
    correct_answers: {
    
    sigma1:sigma1,
    sigma2:sigma2,
    thetap:thetap,


    
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}