const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "weight": "lb/ft",
            "dist": "ft",
            "diameter": "in",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "torque": "lb-in",
            "stress": "ksi",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsWeight = units[unitSystems[unitSel]].weight;
 

diameter = math.pickRandom([0.5,1,1.5,2]);
weight = math.pickRandom([10,15,20]);

TB= weight*4*2*12;
c = diameter/2;
J = (math.pi/2)*c**4;
t1 = math.round( (TB*c/J)/10**3, 3);


data = {
    params: {

    diameter:diameter,
    weight:weight,
   


    unitsDiameter:unitsDiameter,
    unitsStress:unitsStress,
    unitsTorque:unitsTorque,
    unitsWeight:unitsWeight,



    },
    correct_answers: {
        TB:TB,
        t1:t1,


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}