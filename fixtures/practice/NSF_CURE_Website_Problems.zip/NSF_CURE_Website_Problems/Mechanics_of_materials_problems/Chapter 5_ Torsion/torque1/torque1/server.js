const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "distload": "kN/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "kip",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    

  


shearstress1 = math.pickRandom([90,100,120]);
diameter1 = math.pickRandom([100,120,140]);
diameter2 = math.pickRandom([70,75,80]);

c = (diameter1/2)*10**(-3);
J = (math.pi*c**4)/2;

c1 = (diameter2/2)*10**(-3);
J2 = (math.pi*(c**4 - c1**4))/2;

T1 = math.round( (shearstress1*10**6*J)/c, 2);
T2 = math.round( (shearstress1*10**6*J2)/c1, 2);



data = {
    params: {
    
    shearstress1:shearstress1,
    diameter1:diameter1,
    diameter2:diameter2,
    

    unitsLength:unitsLength,
    unitsStress:unitsStress,
    unitsTorque:unitsTorque,


    


    },
    correct_answers: {
        
    T1:T1,
    T2:T2,
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}