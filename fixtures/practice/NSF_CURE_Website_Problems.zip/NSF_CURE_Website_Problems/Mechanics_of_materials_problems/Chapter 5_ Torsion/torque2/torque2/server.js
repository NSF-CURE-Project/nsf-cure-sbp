const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "N",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
 
diameter = math.pickRandom([30,40,50,60,70]);
stress = math.pickRandom([50,60,70]);

c = diameter/2000;
J = (math.pi/2)*c**4;
T1 = math.round( (900 + (stress*10**6*J/c))/1000, 2);
TCD = math.abs(1500 - T1);
TDE = math.abs(1800 - T1);
t1 = math.round( (TCD*c/J)/10**6, 1);
t2 = math.round( (TDE*c/J)/10**6, 1);


data = {
    params: {

    diameter:diameter,
    stress:stress,
   


    unitsDiameter:unitsDiameter,
    unitsStress: unitsStress,
    unitsMoment: unitsMoment,



    },
    correct_answers: {
        T1:T1,
        t1:t1,
        t2:t2,


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}