const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "diameter":"mm",
            "area":"mm\u00B2",
            "force": "kN",
            "torque":"kN-m",
            "stress":"MPa",
            "shearstrain":"rad",
            "distload": "kN/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "ft",
            "diameter":"in",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "kip",
            "torque":"lb-in",
            "stress":"ksi",
            "shearstrain":"rad",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsTorque = units[unitSystems[unitSel]].torque;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    

  


diameter = math.pickRandom([40,60,80,100]);
TA = 414.29;
c = diameter/2000;
J = (math.pi/2)*(c**4);

ss1 = math.round( (TA*c)/(J*10**6), 2);


data = {
    params: {
    

    diameter:diameter,

    

    unitsDiameter:unitsDiameter,
    unitsStress:unitsStress,


    


    },
    correct_answers: {
        
    ss1:ss1,
    
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}