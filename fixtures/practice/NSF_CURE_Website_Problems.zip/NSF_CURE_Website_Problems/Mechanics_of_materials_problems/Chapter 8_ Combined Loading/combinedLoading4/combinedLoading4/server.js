const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "kN",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "in.",
            "diameter": "in.",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "ksi",
            "pressure": "psi"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsPressure = units[unitSystems[unitSel]].pressure;
 

force = math.pickRandom([150,175,200,225,250]);
N = force*-1000;
My = force*-1000*0.05;
Mz = force*0.075*1000;
A = 0.1*0.15;
Iy = (1/12)*0.15*(0.1**3);
Iz = (1/12)*0.1*(0.15**3);
ya = 0.075; 
yb = 0.075; 
za = 0.05;
zb = -0.05
sa = math.abs(math.round( ((N/A) - (Mz*ya)/(Iz) + (My*za)/(Iy))/(10**6), 3));
sb = math.abs(math.round( ((N/A) - (Mz*yb)/(Iz) + (My*zb)/(Iy))/(10**6), 3));



data = {
    params: {

    force:force,
    
   


    unitsForce:unitsForce,
    unitsStress:unitsStress,


    },
    correct_answers: {
        sa:sa,
        sb:sb,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}