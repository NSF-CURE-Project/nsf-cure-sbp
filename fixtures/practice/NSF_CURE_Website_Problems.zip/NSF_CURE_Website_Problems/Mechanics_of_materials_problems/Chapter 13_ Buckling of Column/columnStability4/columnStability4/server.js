const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "kN",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "inertia": "m\u2074",
            "temperature": "\u00B0C",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "diameter": "in.",
            "force": "kip",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "ksi",
            "area": "in\u00B2",
            "pressure": "psi"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsPressure = units[unitSystems[unitSel]].pressure;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    unitsTemperature = units[unitSystems[unitSel]].temperature;
    unitsArea = units[unitSystems[unitSel]].area;
 


diameter = math.pickRandom([35,40,45,50]);
d = diameter/1000;
r = d/2;
A = (math.pi/4)*(d**2);
I = (math.pi/4)*(r**4);
gap = 2/1000;
K = 0.7;
L = 1;
E = 103*10**9;
a = 17*10**-6;
t = math.round( (1/a)*((math.pi**2*I)/(A*((K*L)**2)) + gap), 2);
P = math.round( (A*E*((a*t) - gap))/1000, 2);
cs = math.round( (P*1000/A)/(10**6), 2); 

data = {
    params: {

    
    diameter:diameter,

   


   
    unitsDiameter:unitsDiameter,
    unitsTemperature:unitsTemperature,
    unitsForce:unitsForce,
    unitsStress:unitsStress,



    },
    correct_answers: {
        t:t,
        P:P,
        cs:cs,
        
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}