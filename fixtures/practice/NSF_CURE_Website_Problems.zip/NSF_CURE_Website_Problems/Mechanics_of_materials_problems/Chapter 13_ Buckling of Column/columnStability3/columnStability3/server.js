const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "MN",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "inertia": "m\u2074",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "diameter": "in.",
            "force": "kip",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "ksi",
            "area": "in\u00B2",
            "pressure": "psi"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsPressure = units[unitSystems[unitSel]].pressure;
    unitsInertia = units[unitSystems[unitSel]].inertia;
    unitsArea = units[unitSystems[unitSel]].area;
 

area = math.pickRandom([2.48,2.50,2.52,2.54]);
k = 1;
dist = math.pickRandom([10,12,14,15]);
ra = 0.644;
E = 29*10**3;
cs = math.round( (((math.pi**2)*E)/((k*dist*12/ra)**2)), 2);
cr = math.round( cs*area, 2);



data = {
    params: {

    area:area,
    dist:dist,

   


   
    unitsArea:unitsArea,
    unitsDist:unitsDist,
    unitsForce:unitsForce,


    },
    correct_answers: {
        cr:cr,
        
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}