const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "diameter": "mm",
            "force": "MN",
            "distload": "N/m",
            "moment": "kN-m",
            "stress": "MPa",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "inertia": "m\u2074",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "in.",
            "diameter": "in.",
            "force": "lb",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2",
            "stress": "ksi",
            "pressure": "psi"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsDiameter = units[unitSystems[unitSel]].diameter;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsPressure = units[unitSystems[unitSel]].pressure;
    unitsInertia = units[unitSystems[unitSel]].inertia;
 

dist = math.pickRandom([6,7,8,9]);
stress = 250;
A = (0.3*0.22) - (0.29*0.2);
Ix = (1/12)*0.3*(0.22**3) - (1/12)*0.29*(0.2**3);
Iy = (2/12)*0.01*(0.3**3) + (1/12)*0.2*(0.01**3);
k = 0.7;
E = 73.1*10**9;
cr = math.round( (((math.pi**2)*E*Iy)/((k*dist)**2))/(10**6), 2);
cs = math.round( cr/A, 2);

data = {
    params: {

    dist:dist,
    stress:stress,

   


    unitsDist:unitsDist,
    unitsInertia:unitsInertia,
    unitsStress:unitsStress,
    unitsForce:unitsForce,


    },
    correct_answers: {
        Ix:Ix,
        Iy:Iy,
        cr:cr,
        cs:cs,
    


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}