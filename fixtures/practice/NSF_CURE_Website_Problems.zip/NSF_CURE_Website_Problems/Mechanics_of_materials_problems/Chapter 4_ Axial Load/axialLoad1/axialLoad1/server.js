const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "area":"mm\u00B2",
            "force": "kN",
            "stress":"kPa",
            "shearstrain":"rad",
            "distload": "kN/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in.",
            "temperature":"°F",
            "area":"in\u00B2",
            "force": "kip",
            "stress":"ksi",
            "shearstrain":"rad",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 1;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsArea = units[unitSystems[unitSel]].area;
    unitsTemperature = units[unitSystems[unitSel]].temperature;

  


diameter1 = math.pickRandom([.70,.75]);
diameter2 = math.pickRandom([1,0.95,0.90]);
diameter3 = math.pickRandom([0.4,0.5,0.6]);
stress1 = 18*10**3;

area1 = (math.pi*diameter1**2)/4;
area2 = (math.pi*diameter2**2)/4;
area3 = (math.pi*diameter3**2)/4;

PL1 = -640;
PL2 = 2*150;
PL3 = 6*100;

AD = math.round( (PL1 / (area1 * stress1)) + (PL2 / (area2 * stress1)) + (PL3 / (area3 * stress1)), 3);


data = {
    params: {
    
    diameter1:diameter1,
    diameter2:diameter2,
    diameter3:diameter3,
    stress1:stress1,

    

    unitsLength:unitsLength,
    unitsStress:unitsStress,

    


    },
    correct_answers: {
        
    AD:AD,
    

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}