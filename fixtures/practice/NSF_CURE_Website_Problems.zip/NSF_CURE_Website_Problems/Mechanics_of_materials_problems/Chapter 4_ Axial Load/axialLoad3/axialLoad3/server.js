const math = require('mathjs');
// const mathhelper = require('../../helpers/mathhelper.js');
//const mathhelper = require('../../mathhelper.js');
const generate = () => {


    unitSystems = ['si', "uscs"];
    masslabels = ["mass", "weight"];


    units = {
        "si": {
            "masslabel": "mass",
            "mass": "kg",
            "dist": "m",
            "length": "mm",
            "area":"mm\u00B2",
            "force": "kN",
            "stress":"kPa",
            "shearstrain":"rad",
            "distload": "kN/m",
            "moment": "N-m",
            "angSpeed": "rad/s",
            "angle": "degrees",
            "speed": "m/s",
            "acc": "m/s^2"
        },
        "uscs": {
            "masslabel": "weight",
            "mass": "lb",
            "dist": "ft",
            "length": "in",
            "area":"in\u00B2",
            "force": "kip",
            "stress":"ksi",
            "shearstrain":"rad",
            "distload": "lb/ft",
            "moment": "lb-ft",
            "angSpeed": "rpm",
            "angle": "degrees",
            "speed": "feet/s",
            "acc": "ft/s^2"
        }
    }

    unitSel = 0;
    unitsDist = units[unitSystems[unitSel]].dist;
    unitsSpeed = units[unitSystems[unitSel]].speed;
    unitsMass = units[unitSystems[unitSel]].mass;
    unitsForce = units[unitSystems[unitSel]].force;
    unitsAngSpeed = units[unitSystems[unitSel]].angSpeed;
    unitsAngle = units[unitSystems[unitSel]].angle;
    unitsAcc = units[unitSystems[unitSel]].acc;
    masslabel = units[unitSystems[unitSel]].masslabel;
    unitsDistload = units[unitSystems[unitSel]].distload;
    unitsMoment = units[unitSystems[unitSel]].moment;
    unitsLength = units[unitSystems[unitSel]].length;
    unitsStress = units[unitSystems[unitSel]].stress;
    unitsShearstrain = units[unitSystems[unitSel]].shearstrain;
    unitsArea = units[unitSystems[unitSel]].area;

  

diameter = math.pickRandom([80,90,100]);
force = math.pickRandom([16,18,20]);
distload = math.pickRandom([10,12,14]);
height = math.pickRandom([2,3,4]);

Area = (math.pi/4)*(diameter/1000)**2;
E = 13.1 * 10 ** 9;

upper = (distload * height ** 3) / (6 * height) - force * height;
lower = 0;
integralValue = upper - lower;

d_A = math.round((1000 / (Area * E)) * integralValue, 7);
F = force - (height*distload)/2;




data = {
    params: {
    
    distload:distload,
    diameter:diameter,
    force:force,
    height:height,



    unitsLength:unitsLength,
    unitsForce:unitsForce,
    unitsDist:unitsDist,
    unitsDistload:unitsDistload,

    




    },
    correct_answers: {
        
    F:F,
    d_A:d_A,

    
   


},
   nDigits: 2,
   sigfigs:2


}


console.log(data);
return data;
}
generate();
module.exports = {
    generate
}